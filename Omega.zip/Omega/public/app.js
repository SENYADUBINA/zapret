const form = document.getElementById('listing-form');
const listingsEl = document.getElementById('listings');
const statusEl = document.getElementById('status');
const refreshButton = document.getElementById('refresh');

const formatPrice = (value) =>
  new Intl.NumberFormat('ru-RU', { style: 'currency', currency: 'RUB' }).format(value);

const formatDate = (value) =>
  new Intl.DateTimeFormat('ru-RU', {
    dateStyle: 'medium',
    timeStyle: 'short'
  }).format(new Date(value));

const renderListings = (items) => {
  listingsEl.innerHTML = '';

  if (!items.length) {
    listingsEl.innerHTML = '<p>Пока нет объявлений. Будьте первым!</p>';
    return;
  }

  items.forEach((item) => {
    const card = document.createElement('article');
    card.className = 'listing';

    if (item.image_path) {
      const img = document.createElement('img');
      img.src = item.image_path;
      img.alt = item.title;
      card.appendChild(img);
    }

    const title = document.createElement('h3');
    title.textContent = item.title;
    card.appendChild(title);

    const description = document.createElement('p');
    description.textContent = item.description;
    card.appendChild(description);

    const price = document.createElement('div');
    price.className = 'price';
    price.textContent = formatPrice(item.price);
    card.appendChild(price);

    const meta = document.createElement('div');
    meta.className = 'meta';
    meta.textContent = `Опубликовано: ${formatDate(item.created_at)}`;
    card.appendChild(meta);

    listingsEl.appendChild(card);
  });
};

const loadListings = async () => {
  const response = await fetch('/api/listings');
  const data = await response.json();
  renderListings(data);
};

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  statusEl.textContent = 'Отправляем...';

  const formData = new FormData(form);

  try {
    const response = await fetch('/api/listings', {
      method: 'POST',
      body: formData
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Не удалось добавить объявление.');
    }

    form.reset();
    statusEl.textContent = 'Готово! Объявление опубликовано.';
    await loadListings();
  } catch (error) {
    statusEl.textContent = error.message;
  }
});

refreshButton.addEventListener('click', () => {
  loadListings();
});

loadListings();